package Java_OOP.Interfaces_and_Abstraction.BirthdayCelebrations;

public interface Identifiable {
    String getId();
}
