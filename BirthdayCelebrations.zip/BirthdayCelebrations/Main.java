package Java_OOP.Interfaces_and_Abstraction.BirthdayCelebrations;

public class Main {
    public static void main(String[] args) {

    }
}
