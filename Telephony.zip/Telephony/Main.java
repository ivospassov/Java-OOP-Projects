package Java_OOP.Interfaces_and_Abstraction.Telephony;

public class Main {
    public static void main(String[] args) {

    }
}
