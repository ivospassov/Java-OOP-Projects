package Java_OOP.Interfaces_and_Abstraction.Telephony;

import java.util.List;

public class Smartphone implements Callable, Browsable {
    private List<String> numbers;
    private List<String> urls;

    public Smartphone(List<String> numbers, List<String> urls) {
        this.numbers = numbers;
        this.urls = urls;
    }

    @Override
    public String call() {
        return printCallResult(numbers);
    }

    @Override
    public String browse() {
        return printUrlResult(urls);
    }

    private static String printCallResult(List<String> numbers) {
        StringBuilder stringBuilder = new StringBuilder();
        boolean isInvalid = false;

        for (String currentNumber : numbers) {
            if (currentNumber.equals(numbers.get(numbers.size() - 1))) {
                break;
            }
            for (char symbol : currentNumber.toCharArray()) {
                if (!Character.isDigit(symbol)) {
                    isInvalid = true;
                    break;
                }
            }
            if (isInvalid) {
                stringBuilder.append("Invalid number!").append(System.lineSeparator());
                isInvalid = false;
            } else {
                stringBuilder.append("Calling... ").append(currentNumber).append(System.lineSeparator());
            }
        }

        for (char symbol : numbers.get(numbers.size() - 1).toCharArray()) {
            if (!Character.isDigit(symbol)) {
                isInvalid = true;
                break;
            }
        }
        if (isInvalid) {
            stringBuilder.append("Invalid number!");
        } else {
            stringBuilder.append("Calling... ").append(numbers.get(numbers.size() - 1));
            return stringBuilder.toString();
        }
        return stringBuilder.toString();
    }

    private static String printUrlResult(List<String> urls) {
        boolean isInvalid = false;
        StringBuilder stringBuilder = new StringBuilder();

        for (String currentUrl : urls) {
            if (currentUrl.equals(urls.get(urls.size() - 1))) {
                break;
            }
            for (char symbol : currentUrl.toCharArray()) {
                if (Character.isDigit(symbol)) {
                    isInvalid = true;
                    break;
                }
            }
            if (isInvalid) {
                isInvalid = false;
                stringBuilder.append("Invalid URL!").append(System.lineSeparator());
            } else {
                stringBuilder
                        .append("Browsing: ")
                        .append(currentUrl)
                        .append("!")
                        .append(System.lineSeparator());
            }
        }

        for (char symbol : urls.get(urls.size() - 1).toCharArray()) {
            if (Character.isDigit(symbol)) {
                isInvalid = true;
                break;
            }
        }

        if (isInvalid) {
            isInvalid = false;
            stringBuilder.append("Invalid URL!");
        } else {
            stringBuilder
                    .append("Browsing: ")
                    .append(urls.get(urls.size() - 1))
                    .append("!");
        }
        return stringBuilder.toString();
    }
}
