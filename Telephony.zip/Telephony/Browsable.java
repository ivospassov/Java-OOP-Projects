package Java_OOP.Interfaces_and_Abstraction.Telephony;

public interface Browsable {
    String browse();
}
