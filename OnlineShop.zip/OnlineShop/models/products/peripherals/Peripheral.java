package OnlineShop.models.products.peripherals;

import OnlineShop.models.products.Product;

public interface Peripheral extends Product {
    String getConnectionType();
}
