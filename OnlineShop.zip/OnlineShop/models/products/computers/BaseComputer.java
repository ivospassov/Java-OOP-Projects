package OnlineShop.models.products.computers;

import OnlineShop.common.constants.ExceptionMessages;
import OnlineShop.models.products.BaseProduct;
import OnlineShop.models.products.components.Component;
import OnlineShop.models.products.peripherals.Peripheral;

import java.util.ArrayList;
import java.util.List;

public abstract class BaseComputer extends BaseProduct implements Computer {
    private List<Component> components;
    private List<Peripheral> peripherals;

    public BaseComputer(int id, String manufacturer, String model, double price, double overallPerformance) {
        super(id, manufacturer, model, price, overallPerformance);
        this.components = new ArrayList<>();
        this.peripherals = new ArrayList<>();
    }

    @Override
    public double getOverallPerformance() {
        if (components.isEmpty()) {
            return super.getOverallPerformance();
        }

        double sumComponentsPerformance = this.components
                .stream()
                .mapToDouble(Component::getOverallPerformance)
                .sum();

        double averagePerformance = sumComponentsPerformance / this.components.size();

        return super.getOverallPerformance() + averagePerformance;
    }

    @Override
    public double getPrice() {
        double totalPeripheralPrice = this.peripherals
                .stream()
                .mapToDouble(Peripheral::getPrice)
                .sum();

        double totalComponentPrice = this.components
                .stream()
                .mapToDouble(Component::getPrice)
                .sum();

        return super.getPrice() + totalComponentPrice + totalPeripheralPrice;
    }

    @Override
    public List<Component> getComponents() {
        return this.components;
    }

    @Override
    public List<Peripheral> getPeripherals() {
        return this.peripherals;
    }

    @Override
    public void addComponent(Component component) {
        if (this.components.contains(component)) {
            String message = String.format(ExceptionMessages.EXISTING_COMPONENT,
                    component.getClass().getSimpleName(), this.getClass().getSimpleName(), this.getId());

            throw new IllegalArgumentException(message);
        }
        this.components.add(component);
    }

    @Override
    public Component removeComponent(String componentType) {
        Component searchedComponent = this.components
                .stream()
                .filter(component -> component.getClass().getSimpleName().equals(componentType))
                .findFirst()
                .orElse(null);

        if (this.components.isEmpty() || searchedComponent == null) {
            String message = String.format(ExceptionMessages.NOT_EXISTING_COMPONENT,
                    componentType, this.getClass().getSimpleName(), this.getId());

            throw new IllegalArgumentException(message);
        }

        this.components.remove(searchedComponent);
        return searchedComponent;
    }

    @Override
    public void addPeripheral(Peripheral peripheral) {
        if (peripherals.contains(peripheral)) {
            String message = String.format(ExceptionMessages.EXISTING_PERIPHERAL,
                    peripheral.getClass().getSimpleName(), this.getClass().getSimpleName(), this.getId());
            throw new IllegalArgumentException(message);
        }
        this.peripherals.add(peripheral);
    }

    @Override
    public Peripheral removePeripheral(String peripheralType) {
        Peripheral searchedPeripheral = peripherals
                .stream()
                .filter(peripheral -> peripheral.getClass().getSimpleName().equals(peripheralType))
                .findFirst()
                .orElse(null);

        if (this.peripherals.isEmpty() || searchedPeripheral == null) {
            String message = String.format(ExceptionMessages.NOT_EXISTING_PERIPHERAL,
                    peripheralType, this.getClass().getSimpleName(), this.getId());

            throw new IllegalArgumentException(message);
        }

        this.peripherals.remove(searchedPeripheral);
        return searchedPeripheral;
    }

    @Override
    public String toString() {
        String overrideToString = super.toString();
        StringBuilder stringBuilder = new StringBuilder();

        double allPeripherals = this.peripherals
                .stream()
                .mapToDouble(Peripheral::getOverallPerformance)
                .sum();

        double averageOverallPerformance = allPeripherals / peripherals.size();

        stringBuilder
                .append(overrideToString)
                .append(System.lineSeparator())
                .append(String.format(" Components (%d):", this.components.size()))
                .append(System.lineSeparator());

        this.components.forEach(component -> stringBuilder
                .append("  ".concat(component.toString()))
                .append(System.lineSeparator()));

        stringBuilder
                .append(String.format(" Peripherals (%d); Average Overall Performance (%f):", this.peripherals.size(), averageOverallPerformance))
                .append(System.lineSeparator());

        this.peripherals.forEach(peripheral -> stringBuilder
                .append("  ".concat(peripheral.toString()))
                .append(System.lineSeparator()));

        return stringBuilder.toString();
    }
}
