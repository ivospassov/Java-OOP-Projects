package OnlineShop.models.products.computers;

import java.util.Comparator;

public class ComputerPerformanceComparator implements Comparator<Computer> {
    @Override
    public int compare(Computer firstComputer, Computer secondComputer) {
        return Double.compare(firstComputer.getOverallPerformance(), secondComputer.getOverallPerformance());
    }
}
