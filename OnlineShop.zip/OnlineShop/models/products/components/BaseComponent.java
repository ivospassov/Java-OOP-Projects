package OnlineShop.models.products.components;

import OnlineShop.models.products.BaseProduct;

public abstract class BaseComponent extends BaseProduct implements Component{
    private int generation;

    public BaseComponent(int id, String manufacturer, String model, double price, double overallPerformance, int generation) {
        super(id, manufacturer, model, price, overallPerformance);
        this.generation = generation;
    }

    @Override
    public String toString() {
        String overrideToString = super.toString();
        return overrideToString.concat(String.format(" Generation: %s", this.generation));
    }

    @Override
    public int getGeneration() {
        return this.generation;
    }
}
