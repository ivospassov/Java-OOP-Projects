package OnlineShop.models.products.components;

import OnlineShop.models.products.Product;

public interface Component extends Product {

    int getGeneration();
}
