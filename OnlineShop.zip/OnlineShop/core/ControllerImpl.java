package OnlineShop.core;

import OnlineShop.common.constants.ExceptionMessages;
import OnlineShop.common.constants.OutputMessages;
import OnlineShop.core.interfaces.Controller;
import OnlineShop.models.products.components.*;
import OnlineShop.models.products.computers.Computer;
import OnlineShop.models.products.computers.ComputerPerformanceComparator;
import OnlineShop.models.products.computers.DesktopComputer;
import OnlineShop.models.products.computers.Laptop;
import OnlineShop.models.products.peripherals.*;

import java.util.*;
import java.util.stream.Collectors;

public class ControllerImpl implements Controller {
    private Map<Integer, Computer> computers;

    public ControllerImpl() {
        computers = new LinkedHashMap<>();
    }

    @Override
    public String addComputer(String computerType, int id, String manufacturer, String model, double price) {
        if (this.computers.containsKey(id)) {
            throw new IllegalArgumentException(ExceptionMessages.EXISTING_COMPUTER_ID);
        }

        Computer computer = null;
        switch (computerType) {
            case "DesktopComputer":
                computer = new DesktopComputer(id, manufacturer, model, price);
                break;

            case "Laptop":
                computer = new Laptop(id, manufacturer, model, price);
                break;

            default:
                throw new IllegalArgumentException(ExceptionMessages.INVALID_COMPONENT_TYPE);
        }

        this.computers.put(id, computer);
        return String.format(OutputMessages.ADDED_COMPUTER, id);
    }

    @Override
    public String addPeripheral(int computerId, int id, String peripheralType, String manufacturer, String model, double price, double overallPerformance, String connectionType) {
        Computer computer = this.computers.get(computerId);

        if (computer == null) {
            throw new IllegalArgumentException(ExceptionMessages.NOT_EXISTING_COMPUTER_ID);
        }

        Peripheral searchedPeripheral = computer.getPeripherals()
                .stream()
                .filter(peripheral -> peripheral.getClass().getSimpleName().equals(peripheralType))
                .findFirst()
                .orElse(null);

        if (searchedPeripheral != null) {
            throw new IllegalArgumentException(ExceptionMessages.EXISTING_PERIPHERAL_ID);
        }

        Peripheral peripheral = null;
        switch (peripheralType) {
            case "Headset":
                peripheral = new Headset(id, manufacturer, model, price, overallPerformance, connectionType);
                break;

            case "Keyboard":
                peripheral = new Keyboard(id, manufacturer, model, price, overallPerformance, connectionType);
                break;

            case "Monitor":
                peripheral = new Monitor(id, manufacturer, model, price, overallPerformance, connectionType);
                break;

            case "Mouse":
                peripheral = new Mouse(id, manufacturer, model, price, overallPerformance, connectionType);
                break;

            default:
                throw new IllegalArgumentException(ExceptionMessages.INVALID_PERIPHERAL_TYPE);
        }

        computer.addPeripheral(peripheral);
        return String.format(OutputMessages.ADDED_PERIPHERAL, peripheralType, id, computerId);
    }

    @Override
    public String removePeripheral(String peripheralType, int computerId) {
        Computer computer = this.computers.get(computerId);

        if (computer == null) {
            throw new IllegalArgumentException(ExceptionMessages.NOT_EXISTING_COMPUTER_ID);
        }

        Peripheral searchedPeripheral = computer.getPeripherals()
                .stream()
                .filter(peripheral -> peripheral.getClass().getSimpleName().equals(peripheralType))
                .findFirst()
                .orElse(null);

        if (searchedPeripheral != null) {
            computer.removePeripheral(searchedPeripheral.getClass().getSimpleName());
            computer.getPeripherals().remove(searchedPeripheral);
            return String.format(OutputMessages.REMOVED_PERIPHERAL, peripheralType, searchedPeripheral.getId());
        }
        return null;
    }

    @Override
    public String addComponent(int computerId, int id, String componentType, String manufacturer, String model, double price, double overallPerformance, int generation) {
        Computer computer = this.computers.get(computerId);

        if (computer == null) {
            throw new IllegalArgumentException(ExceptionMessages.NOT_EXISTING_COMPUTER_ID);
        }

        Component searchedComponent = computer.getComponents()
                .stream()
                .filter(component -> component.getId() == id)
                .findFirst()
                .orElse(null);

        if (searchedComponent != null) {
            throw new IllegalArgumentException(ExceptionMessages.EXISTING_COMPONENT_ID);
        }

        Component component = null;
        switch (componentType) {
            case "CentralProcessingUnit":
                component = new CentralProcessingUnit(id, manufacturer, model, price, overallPerformance, generation);
                break;

            case "Motherboard":
                component = new Motherboard(id, manufacturer, model, price, overallPerformance, generation);
                break;

            case "PowerSupply":
                component = new PowerSupply(id, manufacturer, model, price, overallPerformance, generation);
                break;

            case "RandomAccessMemory":
                component = new RandomAccessMemory(id, manufacturer, model, price, overallPerformance, generation);
                break;

            case "SolidStateDrive":
                component = new SolidStateDrive(id, manufacturer, model, price, overallPerformance, generation);
                break;

            case "VideoCard":
                component = new VideoCard(id, manufacturer, model, price, overallPerformance, generation);
                break;

            default:
                throw new IllegalArgumentException(ExceptionMessages.INVALID_COMPONENT_TYPE);
        }

        computer.addComponent(component);
        return String.format(OutputMessages.ADDED_COMPONENT, componentType, id, computerId);
    }

    @Override
    public String removeComponent(String componentType, int computerId) {
        Computer computer = this.computers.get(computerId);

        if (computer == null) {
            throw new IllegalArgumentException(ExceptionMessages.NOT_EXISTING_COMPUTER_ID);
        }

        Component component = computer.getComponents()
                .stream()
                .filter(component1 -> component1.getClass().getSimpleName().equals(componentType))
                .findFirst()
                .orElse(null);

        if (component != null) {
            computer.removeComponent(component.getClass().getSimpleName());
            computer.getComponents().remove(component);

            return String.format(OutputMessages.REMOVED_COMPONENT, componentType, component.getId());
        }
        return null;
    }

    @Override
    public String buyComputer(int id) {
        Computer computer = this.computers.get(id);

        if (computer == null) {
            throw new IllegalArgumentException(ExceptionMessages.NOT_EXISTING_COMPUTER_ID);
        }

        this.computers.remove(computer.getId());
        return computer.toString();
    }

    @Override
    public String BuyBestComputer(double budget) {

        List<Computer> computersSortedByPerformance = this.computers.values()
                .stream()
                .sorted(new ComputerPerformanceComparator().reversed())
                .collect(Collectors.toList());

        Computer mostPowerfulComputer = computersSortedByPerformance.get(0);

        if (computers.isEmpty() || mostPowerfulComputer.getPrice() > budget) {
            String message = String.format(ExceptionMessages.CAN_NOT_BUY_COMPUTER, budget);
            throw new IllegalArgumentException(message);
        }

        this.computers.remove(mostPowerfulComputer.getId());
        return mostPowerfulComputer.toString();
    }

    @Override
    public String getComputerData(int id) {
        Computer computer = this.computers.get(id);

        if (computer == null) {
            throw new IllegalArgumentException(ExceptionMessages.NOT_EXISTING_COMPUTER_ID);
        }

        return computer.toString();
    }
}
