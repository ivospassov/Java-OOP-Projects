package Java_OOP.Polymorphism.Shape;

public class Main {
    public static void main(String[] args) {
        Shape shape = new Rectangle(4, 5);

        System.out.println(shape.calculateArea());
        System.out.println(shape.calculatePerimeter());

        Shape shape1 = new Circle(4);

        System.out.println(shape1.calculatePerimeter());
        System.out.println(shape1.calculateArea());
    }
}
