package FairyShop.models;

import java.util.ArrayDeque;
import java.util.Deque;

public class ShopImpl implements Shop {
    @Override
    public void craft(Present present, Helper helper) {
        Deque<Instrument> instrumentDeque = new ArrayDeque<>(helper.getInstruments());

        while (!present.isDone() && helper.canWork() && !instrumentDeque.isEmpty()) {

            Instrument currentInstrument = instrumentDeque.poll();

            while (!currentInstrument.isBroken() && helper.canWork() && !present.isDone()) {
                currentInstrument.use();
                helper.work();
                present.getCrafted();
            }
        }
    }
}
