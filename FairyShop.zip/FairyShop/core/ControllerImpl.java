package FairyShop.core;

import FairyShop.common.ConstantMessages;
import FairyShop.common.ExceptionMessages;
import FairyShop.models.*;
import FairyShop.repositories.HelperRepository;
import FairyShop.repositories.PresentRepository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class ControllerImpl implements Controller{
    private HelperRepository helperRepository;
    private PresentRepository presentRepository;
    private Shop shop;

    public ControllerImpl() {
        this.helperRepository = new HelperRepository();
        this.presentRepository = new PresentRepository();
        this.shop = new ShopImpl();
    }

    @Override
    public String addHelper(String type, String helperName) {
        Helper helper = null;
        switch (type) {
            case "Happy":
                helper = new Happy(helperName);
                break;

            case "Sleepy":
                helper = new Sleepy(helperName);
                break;

            default:
                throw new IllegalArgumentException(ExceptionMessages.HELPER_TYPE_DOESNT_EXIST);
        }

        this.helperRepository.add(helper);
        return String.format(ConstantMessages.ADDED_HELPER, type, helperName);
    }

    @Override
    public String addInstrumentToHelper(String helperName, int power) {
        Helper helper = this.helperRepository.findByName(helperName);

        if (helper == null) {
            throw new IllegalArgumentException(ExceptionMessages.HELPER_DOESNT_EXIST);
        }

        Instrument instrument = new InstrumentImpl(power);
        helper.addInstrument(instrument);

        return String.format(ConstantMessages.SUCCESSFULLY_ADDED_INSTRUMENT_TO_HELPER, power, helperName);
    }

    @Override
    public String addPresent(String presentName, int energyRequired) {
        Present presentToAdd = new PresentImpl(presentName, energyRequired);
        this.presentRepository.add(presentToAdd);

        return String.format(ConstantMessages.SUCCESSFULLY_ADDED_PRESENT, presentName);
    }

    @Override
    public String craftPresent(String presentName) {
        List<Helper> requiredHelpers = this.helperRepository.getModels()
                .stream()
                .filter(helper -> helper.getEnergy() > 50)
                .collect(Collectors.toList());

        if (requiredHelpers.isEmpty()) {
            throw new IllegalArgumentException(ExceptionMessages.NO_HELPER_READY);
        }

        Present presentToCraft = this.presentRepository.findByName(presentName);

        Collection<Instrument> instrumentsBeforeWork = new ArrayList<>();

        for (Helper helper : requiredHelpers) {
            instrumentsBeforeWork.addAll(helper.getInstruments());
        }

        Collection<Instrument> brokenInst = new ArrayList<>();
        for (Helper helper : requiredHelpers) {
            this.shop.craft(presentToCraft, helper);
            Collection<Instrument> numBroken = helper.getInstruments().stream().filter(Instrument::isBroken).collect(Collectors.toList());
        }

        String isDone = presentToCraft.isDone()
                ? "done"
                : "not done";

        int brokenInstrumentsNum = instrumentsBeforeWork.size() - brokenInst.size();

        return String.format(ConstantMessages.PRESENT_DONE, presentName, isDone) +
                String.format(ConstantMessages.COUNT_BROKEN_INSTRUMENTS, brokenInstrumentsNum);
    }

    @Override
    public String report() {
        List<Present> craftedPresents = this.presentRepository.getModels()
                .stream()
                .filter(Present::isDone)
                .collect(Collectors.toList());

        int craftedNum = craftedPresents.size();

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder
                .append(String.format("%d presents are done!%n", craftedNum))
                .append("Helpers info:\n");

        for (Helper helper : helperRepository.getModels()) {
            List<Instrument> unbrokenInst = helper.getInstruments()
                    .stream()
                    .filter(instrument -> !instrument.isBroken())
                    .collect(Collectors.toList());

            stringBuilder.append(String.format("Name: %s\n", helper.getName()))
                    .append(String.format("Energy: %d\n", helper.getEnergy()))
                    .append(String.format("Instruments: %d not broken left\n", unbrokenInst.size()));
        }

        return stringBuilder.toString();
    }
}
