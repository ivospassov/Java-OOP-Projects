package FairyShop.repositories;

import FairyShop.models.Helper;

import java.util.*;

public class HelperRepository implements Repository<Helper> {
    private Map<String, Helper> helpers;

    public HelperRepository() {
        this.helpers = new LinkedHashMap<>();
    }

    @Override
    public Collection<Helper> getModels() {
        return Collections.unmodifiableCollection(this.helpers.values());
    }

    @Override
    public void add(Helper helper) {
        this.helpers.putIfAbsent(helper.getName(), helper);
    }

    @Override
    public boolean remove(Helper helper) {
        if (this.helpers.containsKey(helper.getName())) {
            this.helpers.remove(helper.getName());
            return true;
        }
        return false;
    }

    @Override
    public Helper findByName(String name) {
        return this.helpers.get(name);
    }
}
