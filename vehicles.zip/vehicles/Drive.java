package vehicles;

public interface Drive {
    String drive(double distance);
}
