package vehicles;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] input = scanner.nextLine().split("\\s+");
        Vehicle car = createVehicle(input);

        input = scanner.nextLine().split("\\s+");
        Vehicle truck = createVehicle(input);

        input = scanner.nextLine().split("\\s+");
        Vehicle bus = createVehicle(input);

        Map<String,Vehicle> vehicles = new LinkedHashMap<>();
        vehicles.put("Car", car);
        vehicles.put("Truck", truck);
        vehicles.put("Bus", bus);

        int numberOfCommands = Integer.parseInt(scanner.nextLine());
        for (int i = 1; i <= numberOfCommands; i++) {
            String[] dataInput = scanner.nextLine().split("\\s+");
            String command = dataInput[0];
            String vehicleType = dataInput[1];

            switch (command) {
                case "Drive":
                    double distance = Double.parseDouble(dataInput[2]);
                    Vehicle vehicle = vehicles.get(vehicleType);
                    if (vehicle instanceof Bus) {
                        bus.setFuelConsumption(bus.getFuelConsumption() + 1.4);
                        System.out.println(bus.drive(distance));
                        bus.setFuelConsumption(bus.getFuelConsumption() - 1.4);
                    } else {
                        String message = vehicles.get(vehicleType).drive(distance);
                        System.out.println(message);
                    }
                    break;

                case "Refuel":
                    double liters = Double.parseDouble(dataInput[2]);
                    if (vehicleType.equals("Car")) {
                        car.refuel(liters);
                    } else if (vehicleType.equals("Truck")) {
                        truck.refuel(liters);
                    } else if (vehicleType.equals("Bus")) {
                        bus.refuel(liters);
                    }
                    break;

                case "DriveEmpty":
                    double emptyBusDistanceToDrive = Double.parseDouble(dataInput[2]);
                    String driveEmptyMessage = bus.drive(emptyBusDistanceToDrive);
                    System.out.println(driveEmptyMessage);
                    break;
            }
        }

        System.out.println(printResult(car, truck, bus));
    }

    private static String printResult(Vehicle car, Vehicle truck, Vehicle bus) {
        return String.format("Car: %.2f", car.getFuelQuantity()) +
                System.lineSeparator() +
                String.format("Truck: %.2f", truck.getFuelQuantity()) +
                System.lineSeparator() +
                String.format("Bus: %.2f", bus.getFuelQuantity());
    }

    private static Vehicle createVehicle(String[] input) {
        String vehicleType = input[0];
        double fuelQuantity = Double.parseDouble(input[1]);
        double fuelConsumption = Double.parseDouble(input[2]);
        double tankCapacity = Double.parseDouble(input[3]);

        Vehicle vehicle = null;
        switch (vehicleType) {
            case "Car":
                vehicle = new Car(fuelQuantity, fuelConsumption, tankCapacity);
                break;

            case "Truck":
                vehicle = new Truck(fuelQuantity, fuelConsumption, tankCapacity);
                break;

            case "Bus":
                vehicle = new Bus(fuelQuantity, fuelConsumption, tankCapacity);
                break;
        }
        return vehicle;
    }
}
