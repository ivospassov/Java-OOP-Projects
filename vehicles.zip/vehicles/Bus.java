package vehicles;

public class Bus extends Vehicle{
    private final static double ADDITIONAL_AC_CONSUMPTION = 1.4;
    private boolean isEmpty;

    public Bus(double fuelQuantity, double fuelConsumption, double tankCapacity) {
        super(fuelQuantity, fuelConsumption, tankCapacity);
        this.isEmpty = true;
    }

    public void setEmpty(boolean empty) {
        if (!isEmpty && empty) {
            //-1.4 Fuel consumption
            this.fuelConsumption -= ADDITIONAL_AC_CONSUMPTION;
        }

        if (isEmpty && !empty) {
            //+1.4 Fuel consumption
            this.fuelConsumption += ADDITIONAL_AC_CONSUMPTION;
        }
    }

    public String drive(double distance, boolean empty) {
        this.setEmpty(empty);
        return super.drive(distance);
    }
}
