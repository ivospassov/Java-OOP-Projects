package ChristmasRaces.entities.cars;

import ChristmasRaces.common.ExceptionMessages;

public class SportsCar extends BaseCar{
    private final static double DEFAULT_CUBIC_CENTIMETERS = 3000;
    private final static int MINIMUM_HORSEPOWER = 250;
    private final static int MAXIMUM_HORSEPOWER = 450;

    public SportsCar(String model, int horsePower) {
        super(model, horsePower, DEFAULT_CUBIC_CENTIMETERS);
    }

    @Override
    protected void checkHorsePower(int horsePower) {
        if (horsePower < MINIMUM_HORSEPOWER || horsePower > MAXIMUM_HORSEPOWER) {
            String message = String.format(ExceptionMessages.INVALID_HORSE_POWER, horsePower);
            throw new IllegalArgumentException(message);
        }
    }
}
