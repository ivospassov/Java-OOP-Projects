package ChristmasRaces.entities.cars;

import ChristmasRaces.common.ExceptionMessages;

public class MuscleCar extends BaseCar{
    private final static double DEFAULT_CUBIC_CENTIMETERS = 5000;
    private final static int MINIMUM_HORSEPOWER = 400;
    private final static int MAXIMUM_HORSEPOWER = 600;
    public MuscleCar(String model, int horsePower) {
        super(model, horsePower, DEFAULT_CUBIC_CENTIMETERS);
    }

    @Override
    protected void checkHorsePower(int horsePower) {
        if (horsePower < MINIMUM_HORSEPOWER || horsePower > MAXIMUM_HORSEPOWER) {
            String message = String.format(ExceptionMessages.INVALID_HORSE_POWER, horsePower);
            throw new IllegalArgumentException(message);
        }
    }
}
