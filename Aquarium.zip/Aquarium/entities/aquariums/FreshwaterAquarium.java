package Aquarium.entities.aquariums;

public class FreshwaterAquarium extends BaseAquarium{
    private final static int INITIAL_CAPACITY = 50;

    public FreshwaterAquarium(String name) {
        super(name, INITIAL_CAPACITY);
    }
}
