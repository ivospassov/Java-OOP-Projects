package Aquarium.entities.aquariums;

import Aquarium.common.ConstantMessages;
import Aquarium.common.ExceptionMessages;
import Aquarium.entities.decorations.Decoration;
import Aquarium.entities.fish.Fish;

import java.util.ArrayList;
import java.util.Collection;

public abstract class BaseAquarium implements Aquarium{
    private String name;
    private int capacity;
    private Collection<Decoration> decorations;
    private Collection<Fish> fish;

    public BaseAquarium(String name, int capacity) {
        setName(name);
        this.capacity = capacity;
        this.decorations = new ArrayList<>();
        this.fish = new ArrayList<>();
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new NullPointerException(ExceptionMessages.FISH_NAME_NULL_OR_EMPTY);
        }
        this.name = name;
    }

    @Override
    public int calculateComfort() {
        return this.decorations
                .stream()
                .mapToInt(Decoration::getComfort)
                .sum();
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void addFish(Fish fish) {
        if (this.fish.size() >= this.capacity) {
            throw new IllegalStateException(ConstantMessages.NOT_ENOUGH_CAPACITY);
        }
        this.fish.add(fish);
    }

    @Override
    public void removeFish(Fish fish) {
        this.fish.remove(fish);
    }

    @Override
    public void addDecoration(Decoration decoration) {
        this.decorations.add(decoration);
    }

    @Override
    public void feed() {
        for (Fish currentFish : fish) {
            currentFish.eat();
        }
    }

    @Override
    public String getInfo() {
        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append(String.format("%s (%s):\n", this.name, this.getClass().getSimpleName()));

        if (this.fish.isEmpty()) {
            stringBuilder.append("Fish: none\n");
        } else {
            stringBuilder.append("Fish: ");
            for (Fish currentFish : fish) {
                stringBuilder.append(currentFish).append(" ");
            }
            stringBuilder.append(System.lineSeparator());
        }
        stringBuilder.append("Decorations: ").append(this.decorations.size()).append(System.lineSeparator())
                .append("Comfort: ").append(this.calculateComfort());

        return stringBuilder.toString();
    }

    @Override
    public Collection<Fish> getFish() {
        return this.fish;
    }

    @Override
    public Collection<Decoration> getDecorations() {
        return this.decorations;
    }
}
