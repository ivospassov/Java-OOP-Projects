package Aquarium.entities.decorations;

public interface Decoration {
    int getComfort();

    double getPrice();
}
