package Aquarium.entities.fish;

public class SaltwaterFish extends BaseFish{
    private final static int INITIAL_SIZE = 5;

    public SaltwaterFish(String name, String species, double price) {
        super(name, species, price);
        this.setSize(INITIAL_SIZE);
    }

    @Override
    public void eat() {
        int increaseSize = getSize() + 2;
        this.setSize(increaseSize);
    }
}
