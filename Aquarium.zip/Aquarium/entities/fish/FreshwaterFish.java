package Aquarium.entities.fish;

public class FreshwaterFish extends BaseFish{
    private final static int INITIAL_SIZE = 3;

    public FreshwaterFish(String name, String species, double price) {
        super(name, species, price);
        this.setSize(INITIAL_SIZE);
    }


    @Override
    public void eat() {
        int increaseSize = getSize() + 3;
        this.setSize(increaseSize);
    }
}
