package Aquarium.core;

public interface Engine extends Runnable {
}

