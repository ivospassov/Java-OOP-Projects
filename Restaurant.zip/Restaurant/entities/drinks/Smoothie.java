package Restaurant.entities.drinks;

public class Smoothie extends BaseBeverage{
    private final static double SMOOTHIE_PRICE = 4.5;

    public Smoothie(String name, int counter, String brand) {
        super(name, counter, SMOOTHIE_PRICE, brand);
    }
}
