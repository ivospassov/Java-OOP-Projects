package Restaurant.repositories;

import Restaurant.entities.healthyFoods.interfaces.HealthyFood;
import Restaurant.repositories.interfaces.HealthFoodRepository;

import java.util.*;

public class HealthFoodRepositoryImpl implements HealthFoodRepository<HealthyFood> {
    private Map<String, HealthyFood> healthyFoodMap;

    public HealthFoodRepositoryImpl() {
        healthyFoodMap = new LinkedHashMap<>();
    }

    @Override
    public HealthyFood foodByName(String name) {
        return this.healthyFoodMap.get(name);
    }

    @Override
    public Collection<HealthyFood> getAllEntities() {
        return Collections.unmodifiableCollection(this.healthyFoodMap.values());
    }

    @Override
    public void add(HealthyFood healthyFood) {
        this.healthyFoodMap.put(healthyFood.getName(), healthyFood);
    }
}
