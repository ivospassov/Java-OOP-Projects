package Restaurant.repositories;

import Restaurant.entities.drinks.interfaces.Beverages;
import Restaurant.repositories.interfaces.BeverageRepository;

import java.util.*;

public class BeverageRepositoryImpl implements BeverageRepository<Beverages> {
    private Map<String, Beverages> beveragesMap;

    public BeverageRepositoryImpl() {
        this.beveragesMap = new LinkedHashMap<>();
    }

    @Override
    public Beverages beverageByName(String drinkName, String drinkBrand) {
        return this.beveragesMap.get(drinkName);
    }

    @Override
    public Collection<Beverages> getAllEntities() {
        return Collections.unmodifiableCollection(this.beveragesMap.values());
    }

    @Override
    public void add(Beverages beverage) {
        this.beveragesMap.put(beverage.getName(), beverage);
    }
}
