package Restaurant.repositories;

import Restaurant.entities.tables.interfaces.Table;
import Restaurant.repositories.interfaces.TableRepository;

import java.util.*;

public class TableRepositoryImpl implements TableRepository<Table> {
    private Map<Integer, Table> tableMap;

    public TableRepositoryImpl() {
        this.tableMap = new LinkedHashMap<>();
    }

    @Override
    public Collection<Table> getAllEntities() {
        return Collections.unmodifiableCollection(this.tableMap.values());
    }

    @Override
    public void add(Table table) {
        this.tableMap.put(table.getTableNumber(), table);
    }

    @Override
    public Table byNumber(int number) {
        return this.tableMap.get(number);
    }
}
