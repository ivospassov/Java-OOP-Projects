package Restaurant.core;

import Restaurant.common.ExceptionMessages;
import Restaurant.common.OutputMessages;
import Restaurant.core.interfaces.Controller;
import Restaurant.entities.drinks.Fresh;
import Restaurant.entities.drinks.Smoothie;
import Restaurant.entities.healthyFoods.Salad;
import Restaurant.entities.healthyFoods.VeganBiscuits;
import Restaurant.entities.healthyFoods.interfaces.HealthyFood;
import Restaurant.entities.drinks.interfaces.Beverages;
import Restaurant.entities.tables.InGarden;
import Restaurant.entities.tables.Indoors;
import Restaurant.entities.tables.interfaces.Table;
import Restaurant.repositories.interfaces.*;

public class ControllerImpl implements Controller {
    private HealthFoodRepository<HealthyFood> healthyFoodRepository;
    private BeverageRepository<Beverages> beveragesRepository;
    private TableRepository<Table> tableRepository;
    private double closedBillsSum;

    public ControllerImpl(HealthFoodRepository<HealthyFood> healthyFoodRepository,
                          BeverageRepository<Beverages> beveragesRepository,
                          TableRepository<Table> tableRepository) {
        this.healthyFoodRepository = healthyFoodRepository;
        this.beveragesRepository = beveragesRepository;
        this.tableRepository = tableRepository;
    }

    @Override
    public String addHealthyFood(String type, double price, String name) {
        HealthyFood newFood = null;
        switch (type) {
            case "Salad":
                newFood = new Salad(name, price);
                break;

            case "VeganBiscuits":
                newFood = new VeganBiscuits(name, price);
                break;
        }

        HealthyFood healthyFood = this.healthyFoodRepository.foodByName(name);
        if (this.healthyFoodRepository.getAllEntities().contains(healthyFood)) {
            throw new IllegalArgumentException(String.format(ExceptionMessages.FOOD_EXIST, name));
        }

        this.healthyFoodRepository.add(newFood);
        return String.format(OutputMessages.FOOD_ADDED, name);
    }

    @Override
    public String addBeverage(String type, int counter, String brand, String name) {
        Beverages searchedBeverage = type.equals("Fresh")
                ? new Fresh(name, counter, brand)
                : new Smoothie(name, counter, brand);

        Beverages beverage = this.beveragesRepository.beverageByName(name, brand);
        if (beverage == null) {
            this.beveragesRepository.add(searchedBeverage);
            return String.format(OutputMessages.BEVERAGE_ADDED, type, brand);
        }
        throw new IllegalArgumentException(String.format(ExceptionMessages.BEVERAGE_EXIST, name));
    }

    @Override
    public String addTable(String type, int tableNumber, int capacity) {
        Table newTable = type.equals("InGarden")
                ? new InGarden(tableNumber, capacity)
                : new Indoors(tableNumber, capacity);

        Table table = this.tableRepository.byNumber(tableNumber);

        if (table == null) {
            this.tableRepository.add(newTable);
            return String.format(OutputMessages.TABLE_ADDED, tableNumber);
        }

        throw new IllegalArgumentException(String.format(ExceptionMessages.TABLE_IS_ALREADY_ADDED, tableNumber));
    }

    @Override
    public String reserve(int numberOfPeople) {
        Table tableToReserve = this.tableRepository.getAllEntities()
                .stream()
                .filter(table -> !table.isReservedTable() && table.getSize() >= numberOfPeople)
                .findFirst()
                .orElse(null);

        if (tableToReserve == null) {
            return String.format(OutputMessages.RESERVATION_NOT_POSSIBLE, numberOfPeople);
        }

        tableToReserve.reserve(numberOfPeople);
        return String.format(OutputMessages.TABLE_RESERVED, tableToReserve.getTableNumber(), numberOfPeople);
    }

    @Override
    public String orderHealthyFood(int tableNumber, String healthyFoodName) {
        Table searchTable = this.tableRepository.byNumber(tableNumber);

        if (searchTable == null) {
            return String.format(OutputMessages.WRONG_TABLE_NUMBER, tableNumber);
        }

        HealthyFood searchFood = this.healthyFoodRepository.foodByName(healthyFoodName);

        if (searchFood == null) {
            return String.format(OutputMessages.NONE_EXISTENT_FOOD, healthyFoodName);
        }

        searchTable.orderHealthy(searchFood);
        return String.format(OutputMessages.FOOD_ORDER_SUCCESSFUL, healthyFoodName, tableNumber);
    }

    @Override
    public String orderBeverage(int tableNumber, String name, String brand) {
        Table table = tableRepository.byNumber(tableNumber);
        if (table == null) {
            return String.format(OutputMessages.WRONG_TABLE_NUMBER, tableNumber);
        }

        Beverages drink = this.beveragesRepository.getAllEntities().stream()
                .filter(b -> b.getName().equals(name) && b.getBrand().equals(brand))
                .findFirst().orElse(null);

        if (drink == null) {
            return String.format(OutputMessages.NON_EXISTENT_DRINK, name, brand);
        }

        table.orderBeverages(drink);
        return String.format(OutputMessages.BEVERAGE_ORDER_SUCCESSFUL, name, tableNumber);
    }

    @Override
    public String closedBill(int tableNumber) {
        Table table = this.tableRepository.byNumber(tableNumber);
        double tableBill = table.bill();
        table.clear();
        this.closedBillsSum += tableBill;

        return String.format(OutputMessages.BILL, tableNumber, tableBill);
    }


    @Override
    public String totalMoney() {
        return String.format(OutputMessages.TOTAL_MONEY, this.closedBillsSum);
    }
}
