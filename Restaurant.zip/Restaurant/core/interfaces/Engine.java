package Restaurant.core.interfaces;

public interface Engine {
    void run();
}
