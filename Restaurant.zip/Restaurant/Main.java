package Restaurant;

import Restaurant.core.ControllerImpl;
import Restaurant.core.EngineImpl;
import Restaurant.core.interfaces.Controller;
import Restaurant.entities.drinks.interfaces.Beverages;
import Restaurant.entities.healthyFoods.interfaces.HealthyFood;
import Restaurant.entities.tables.interfaces.Table;

import Restaurant.io.ConsoleReader;
import Restaurant.io.ConsoleWriter;
import Restaurant.repositories.BeverageRepositoryImpl;
import Restaurant.repositories.HealthFoodRepositoryImpl;
import Restaurant.repositories.TableRepositoryImpl;
import Restaurant.repositories.interfaces.*;

public class Main {
    public static void main(String[] args) {

        HealthFoodRepository<HealthyFood> healthFoodRepository = new HealthFoodRepositoryImpl();
        BeverageRepository<Beverages> beverageRepository = new BeverageRepositoryImpl();
        TableRepository<Table> tableRepository = new TableRepositoryImpl();

        Controller controller = new ControllerImpl(healthFoodRepository, beverageRepository, tableRepository);

        ConsoleReader reader = new ConsoleReader();
        ConsoleWriter writer = new ConsoleWriter();
        EngineImpl engine = new EngineImpl(reader, writer, controller);
        engine.run();

    }
}
