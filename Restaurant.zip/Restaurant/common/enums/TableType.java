package Restaurant.common.enums;

public enum TableType {
    Indoors,
    InGarden
}
