package Restaurant.common.enums;

public enum BeveragesType {
    Smoothie,
    Fresh
}
