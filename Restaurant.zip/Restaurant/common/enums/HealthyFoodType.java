package Restaurant.common.enums;

public enum HealthyFoodType {
    Salad,
    VeganBiscuits
}
