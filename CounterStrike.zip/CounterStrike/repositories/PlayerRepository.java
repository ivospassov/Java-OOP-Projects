package CounterStrike.repositories;

import CounterStrike.common.ExceptionMessages;
import CounterStrike.models.players.Player;

import java.util.ArrayList;
import java.util.Collection;

public class PlayerRepository implements Repository<Player>{
    private Collection<Player> models;

    public PlayerRepository() {
        this.models = new ArrayList<>();
    }


    @Override
    public Collection<Player> getModels() {
        return this.models;
    }

    @Override
    public void add(Player player) {
        if (player == null) {
            throw new NullPointerException(ExceptionMessages.INVALID_PLAYER_REPOSITORY);
        }
        this.models.add(player);
    }

    @Override
    public boolean remove(Player player) {
        if (this.models.contains(player)) {
            this.models.remove(player);
            return true;
        }
        return false;
    }

    @Override
    public Player findByName(String name) {
        return this.models
                .stream()
                .filter(player -> player.getUsername().equals(name))
                .findFirst()
                .orElse(null);
    }
}
