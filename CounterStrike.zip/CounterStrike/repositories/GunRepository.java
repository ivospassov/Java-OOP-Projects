package CounterStrike.repositories;

import CounterStrike.common.ExceptionMessages;
import CounterStrike.models.guns.Gun;

import java.util.ArrayList;
import java.util.Collection;

public class GunRepository implements Repository<Gun>{
    private Collection<Gun> models;

    public GunRepository() {
        this.models = new ArrayList<>();
    }

    @Override
    public Collection<Gun> getModels() {
        return this.models;
    }

    @Override
    public void add(Gun gun) {
        if (gun == null) {
            throw new NullPointerException(ExceptionMessages.INVALID_GUN_REPOSITORY);
        }
        this.models.add(gun);
    }

    @Override
    public boolean remove(Gun gun) {
        if (this.models.contains(gun)) {
            this.models.remove(gun);
            return true;
        }
        return false;
    }

    @Override
    public Gun findByName(String name) {
        return this.models
                .stream()
                .filter(gun -> gun.getName().equals(name))
                .findFirst()
                .orElse(null);
    }
}
