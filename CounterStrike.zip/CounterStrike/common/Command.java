package CounterStrike.common;

public enum Command {
    AddGun,
    AddPlayer,
    Report,
    StartGame,
    Exit
}
