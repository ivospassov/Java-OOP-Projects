package CounterStrike.models.players;

import CounterStrike.common.ExceptionMessages;
import CounterStrike.models.guns.Gun;

public class PlayerImpl implements Player{
    private String username;
    private int health;
    private int armor;
    private boolean isAlive;
    private Gun gun;

    public PlayerImpl(String username, int health, int armor, Gun gun) {
        setUsername(username);
        setHealth(health);
        setArmor(armor);
        this.isAlive = isAlive();
        setGun(gun);
    }

    @Override
    public String getUsername() {
        return this.username;
    }

    @Override
    public int getHealth() {
        return this.health;
    }

    @Override
    public int getArmor() {
        return this.armor;
    }

    @Override
    public Gun getGun() {
        return this.gun;
    }

    @Override
    public boolean isAlive() {
        return this.getHealth() > 0;
    }

    @Override
    public void takeDamage(int points) {

        if (isAlive) {
            int difference = 0;
            if (points > this.getArmor()) {
                difference = Math.abs(points - this.getArmor());
                setArmor(0);

                //When armor reaches zero we subtract the remaining points from the health points
                //We check if the player will survive
                if (this.getHealth() <= difference) {
                    this.setHealth(0);
                    this.isAlive = false;
                } else {
                    setHealth(this.getHealth() - difference);
                }
            } else {
                setArmor(this.getArmor() - points);
            }
        }
    }

    private void setUsername(String username) {
        if (username == null || username.trim().isEmpty()) {
            throw new NullPointerException(ExceptionMessages.INVALID_PLAYER_NAME);
        }
        this.username = username;
    }

    private void setHealth(int health) {
        if (health < 0) {
            throw new IllegalArgumentException(ExceptionMessages.INVALID_PLAYER_HEALTH);
        }
        this.health = health;
    }

    private void setArmor(int armor) {
        if (armor < 0) {
            throw new IllegalArgumentException(ExceptionMessages.INVALID_PLAYER_ARMOR);
        }
        this.armor = armor;
    }

    private void setGun(Gun gun) {
        if (gun == null) {
            throw new NullPointerException(ExceptionMessages.INVALID_GUN);
        }
        this.gun = gun;
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder
                .append(String.format("%s: %s", this.getClass().getSimpleName(), this.username))
                .append(System.lineSeparator())
                .append(String.format("--Health: %s", this.health))
                .append(System.lineSeparator())
                .append(String.format("--Armor: %s", this.armor))
                .append(System.lineSeparator())
                .append(String.format("--Gun: %s", this.gun.getName()));

        return stringBuilder.toString().trim();
    }
}
