package CounterStrike.models.players;

import java.util.Comparator;

public class PlayerComparator implements Comparator<Player> {

    @Override
    public int compare(Player firstPlayer, Player secondPlayer) {
        if (firstPlayer.getClass().getSimpleName().compareTo(secondPlayer.getClass().getSimpleName()) >= 0) {
            if (Integer.compare(secondPlayer.getHealth(), firstPlayer.getHealth()) > 0) {
                return Integer.compare(secondPlayer.getHealth(), firstPlayer.getHealth());
            } else {
                return firstPlayer.getUsername().compareTo(secondPlayer.getUsername());
            }
        }
        return firstPlayer.getClass().getSimpleName().compareTo(secondPlayer.getClass().getSimpleName());
    }
}
