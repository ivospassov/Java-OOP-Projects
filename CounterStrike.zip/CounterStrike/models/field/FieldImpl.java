package CounterStrike.models.field;

import CounterStrike.common.OutputMessages;
import CounterStrike.models.players.Player;

import java.util.*;
import java.util.stream.Collectors;

public class FieldImpl implements Field{
    @Override
    public String start(Collection<Player> players) {
        List<Player> aliveTerrorists = players
                .stream()
                .filter(player -> player.getClass().getSimpleName().equals("Terrorist"))
                .collect(Collectors.toList());

        List<Player> aliveCounterTerrorists = players
                .stream()
                .filter(player -> player.getClass().getSimpleName().equals("CounterTerrorist"))
                .collect(Collectors.toList());

        while (!aliveTerrorists.isEmpty() && !aliveCounterTerrorists.isEmpty()) {

            Deque<Player> terrorists = new ArrayDeque<>(aliveTerrorists);
            Deque<Player> counterTerrorists = new ArrayDeque<>();

            Player terrorist = terrorists.poll();
            boolean allKilled = false;

            while (terrorist != null && !allKilled) {
                counterTerrorists = new ArrayDeque<>(aliveCounterTerrorists);
//                counterTerrorists = new ArrayDeque<>(aliveCounterTerrorists);
                Player counterTerrorist = counterTerrorists.poll();

                while (counterTerrorist != null) {
                    if (counterTerrorist.isAlive() && terrorist.getGun().getBulletsCount() > 0) {
                        int gunDamage = terrorist.getGun().fire();
                        counterTerrorist.takeDamage(gunDamage);
                    }

                    if (!counterTerrorist.isAlive()) {
                        aliveCounterTerrorists.remove(counterTerrorist);

                        if (aliveCounterTerrorists.isEmpty()) {
                            allKilled = true;
                        }
                    }

                    if (terrorist.getGun().getBulletsCount() <= 0) {
                        terrorist = terrorists.poll();
                    }


                    counterTerrorist = counterTerrorists.poll();
                }
                terrorist = terrorists.poll();
            }

            Deque<Player> remainingCounterTerrorists = new ArrayDeque<>(aliveCounterTerrorists);

            //Now counter terrorist fire back
            Player counterTerrorist = remainingCounterTerrorists.poll();

            while (counterTerrorist != null && !allKilled) {

                Deque<Player> remainingTerrorists = new ArrayDeque<>(aliveTerrorists);
                terrorist = remainingTerrorists.poll();
                while (terrorist != null) {
                    if (terrorist.isAlive() && counterTerrorist.getGun().getBulletsCount() > 0) {
                        int gunDamage = counterTerrorist.getGun().fire();
                        terrorist.takeDamage(gunDamage);
                    }

                    if (!terrorist.isAlive()) {
                        aliveTerrorists.remove(terrorist);
                        if (aliveTerrorists.isEmpty()) {
                            allKilled = true;
                        }
                    }

                    if (counterTerrorist.getGun().getBulletsCount() <= 0) {
                        counterTerrorist = counterTerrorists.poll();
                    }


                    terrorist = remainingTerrorists.poll();
                }
                counterTerrorist = remainingCounterTerrorists.poll();
            }
        }

        if (aliveCounterTerrorists.isEmpty()) {
            return OutputMessages.TERRORIST_WINS;
        }
        return OutputMessages.COUNTER_TERRORIST_WINS;
    }
}
