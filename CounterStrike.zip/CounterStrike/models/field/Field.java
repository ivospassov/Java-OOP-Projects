package CounterStrike.models.field;

import CounterStrike.models.players.Player;

import java.util.Collection;

public interface Field {
    String start(Collection<Player> players);
}
