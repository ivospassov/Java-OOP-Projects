package CounterStrike.models.guns;

public class Pistol extends GunImpl {
    private final static int BULLETS_PER_SHOT = 1;

    public Pistol(String name, int bulletsCount) {
        super(name, bulletsCount);
    }

    @Override
    public int fire() {
        if (this.bulletsCount >= BULLETS_PER_SHOT) {
            this.setBulletsCount(this.bulletsCount - BULLETS_PER_SHOT);
            return BULLETS_PER_SHOT;
        }
        return 0;
    }
}
