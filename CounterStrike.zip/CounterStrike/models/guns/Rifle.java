package CounterStrike.models.guns;

public class Rifle extends GunImpl{
    private final static int BULLETS_PER_SHOT = 10;

    public Rifle(String name, int bulletsCount) {
        super(name, bulletsCount);
    }

    @Override
    public int fire() {
        if (this.bulletsCount >= BULLETS_PER_SHOT) {
            this.setBulletsCount(this.bulletsCount - BULLETS_PER_SHOT);
            return BULLETS_PER_SHOT;
        }
        return 0;
    }
}
