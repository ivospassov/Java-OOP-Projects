package CounterStrike.core;

public interface Engine extends Runnable {
}
