package CounterStrike.core;

import CounterStrike.common.ExceptionMessages;
import CounterStrike.common.OutputMessages;
import CounterStrike.models.field.Field;
import CounterStrike.models.field.FieldImpl;
import CounterStrike.models.guns.Gun;
import CounterStrike.models.guns.Pistol;
import CounterStrike.models.guns.Rifle;
import CounterStrike.models.players.CounterTerrorist;
import CounterStrike.models.players.Player;
import CounterStrike.models.players.PlayerComparator;
import CounterStrike.models.players.Terrorist;
import CounterStrike.repositories.GunRepository;
import CounterStrike.repositories.PlayerRepository;
import CounterStrike.repositories.Repository;

import java.util.ArrayList;
import java.util.List;

public class ControllerImpl implements Controller {
    private Repository<Gun> guns;
    private Repository<Player> players;
    private Field field;

    public ControllerImpl() {
        guns = new GunRepository();
        players = new PlayerRepository();
        field = new FieldImpl();
    }

    @Override
    public String addGun(String type, String name, int bulletsCount) {
        Gun gun = null;
        switch (type) {
            case "Pistol":
                gun = new Pistol(name, bulletsCount);
                break;

            case "Rifle":
                gun = new Rifle(name, bulletsCount);
                break;

            default:
                throw new IllegalArgumentException(ExceptionMessages.INVALID_GUN_TYPE);
        }

        this.guns.add(gun);
        return String.format(OutputMessages.SUCCESSFULLY_ADDED_GUN, name);
    }

    @Override
    public String addPlayer(String type, String username, int health, int armor, String gunName) {
        Player player = null;
        Gun gun = this.guns.findByName(gunName);

        if (gun == null) {
            throw new NullPointerException(ExceptionMessages.GUN_CANNOT_BE_FOUND);
        }

        switch (type) {
            case "Terrorist":
                player = new Terrorist(username, health, armor, gun);
                break;

            case "CounterTerrorist":
                player = new CounterTerrorist(username, health, armor, gun);
                break;

            default:
                throw new IllegalArgumentException(ExceptionMessages.INVALID_PLAYER_TYPE);
        }

        this.players.add(player);
        return String.format(OutputMessages.SUCCESSFULLY_ADDED_PLAYER, username);
    }

    @Override
    public String startGame() {
        return this.field.start(this.players.getModels());
    }

    @Override
    public String report() {
        List<Player> gamePlayers = new ArrayList<>(this.players.getModels());

        StringBuilder stringBuilder = new StringBuilder();

        return gamePlayers
                .stream()
                .sorted(new PlayerComparator())
                .toString();
    }
}
