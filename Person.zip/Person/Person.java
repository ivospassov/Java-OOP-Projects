package Java_OOP.Interfaces_and_Abstraction.Person;

public interface Person {
    String getName();
    String sayHello();
}
