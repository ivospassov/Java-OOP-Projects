package Java_OOP.Interfaces_and_Abstraction.Car;

public interface Rentable extends Car{

    int getMinRentDay();
    double getPricePerDay();
}
