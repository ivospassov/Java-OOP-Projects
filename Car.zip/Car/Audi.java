package Java_OOP.Interfaces_and_Abstraction.Car;

public class Audi extends CarImpl implements Rentable{
    private Integer minRentDay;
    private Double pricePerDay;

    public Audi(String model, String color, int horsePower, String countryProduced, Integer minRentDay, Double pricePerDay) {
        super(model, color, horsePower, countryProduced);
        this.minRentDay = minRentDay;
        this.pricePerDay = pricePerDay;
    }

    @Override
    public int getMinRentDay() {
        return this.minRentDay;
    }

    @Override
    public double getPricePerDay() {
        return this.pricePerDay;
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder
                .append(String.format(
                        "This is %s produced in %s and have %d tires",
                        this.getModel(),
                        this.countryProduced(),
                        Car.TIRES))
                .append(System.lineSeparator())
                .append(String.format("Minimum rental period of %d days. Price per day %f", this.getMinRentDay(), this.getPricePerDay()));

        return stringBuilder.toString();
    }
}
