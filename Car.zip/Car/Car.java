package Java_OOP.Interfaces_and_Abstraction.Car;

public interface Car {
    int TIRES = 4;

    String getModel();
    String getColor();
    Integer getHorsePower();
    String countryProduced();
}
