package Java_OOP.Interfaces_and_Abstraction.Car;

public interface Sellable extends Car{
    double getPrice();
}
