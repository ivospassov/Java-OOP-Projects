//package viceCity.models.neighbourhood;
//
//import viceCity.models.guns.Gun;
//import viceCity.models.players.Player;
//import viceCity.repositories.interfaces.Repository;
//
//import java.util.*;
//
//public class GangNeighbourhood implements Neighbourhood{
//
//    @Override
//    public void action(Player mainPlayer, Collection<Player> civilPlayers) {
//        Repository<Gun> tommyGunRepository = mainPlayer.getGunRepository();
//
//        Deque<Gun> tommyGuns = new ArrayDeque<>(tommyGunRepository.getModels());
//        Deque<Player> players = new ArrayDeque<>(civilPlayers);
//
//        Player player = players.poll();
//        Gun gun = tommyGuns.poll();
//
//        while (player != null && gun != null) {
//            while (gun.canFire() && player.isAlive()) {
//                int shot = gun.fire();
//                player.takeLifePoints(shot);
//            }
//
//            //We check if next weapon is needed or player has 0 lifepoints
//            if (gun.canFire()) {
//                player = players.poll();
//            } else {
//                gun = tommyGuns.poll();
//            }
//        }
//
//        for (Player currentCivilPlayer : civilPlayers) {
//            if (currentCivilPlayer.isAlive()) {
//                Repository<Gun> civilGunsRepository = currentCivilPlayer.getGunRepository();
//                Deque<Gun> civilGuns = new ArrayDeque<>(civilGunsRepository.getModels());
//
//                Gun civilPlayerGun = civilGuns.poll();
//
//                while (civilPlayerGun != null) {
//                    while (mainPlayer.isAlive() && civilPlayerGun.canFire()) {
//                        int shot = civilPlayerGun.fire();
//                        mainPlayer.takeLifePoints(shot);
//                    }
//
//                    if (!mainPlayer.isAlive()) {
//                        return;
//                    }
//                    civilPlayerGun = civilGuns.poll();
//                }
//            }
//        }
//    }
//}
