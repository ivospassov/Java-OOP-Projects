//package viceCity.models.players;
//
//import viceCity.models.guns.Gun;
//import viceCity.repositories.interfaces.Repository;
//
//public class MainPlayer extends BasePlayer{
//    private final static String MAIN_PLAYER_NAME = "Tommy Vercetti";
//    private final static int DEFAULT_LIFE_POINTS = 100;
//
//    public MainPlayer() {
//        super(MAIN_PLAYER_NAME, DEFAULT_LIFE_POINTS);
//    }
//
//}
