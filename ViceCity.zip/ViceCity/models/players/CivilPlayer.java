//package viceCity.models.players;
//
//public class CivilPlayer extends BasePlayer{
//    private final static int DEFAULT_LIFE_POINTS = 50;
//
//    public CivilPlayer(String name) {
//        super(name, DEFAULT_LIFE_POINTS);
//    }
//}
