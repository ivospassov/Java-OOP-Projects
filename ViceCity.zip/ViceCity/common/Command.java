package ViceCity.common;

public enum  Command {
    AddPlayer,
    AddGun,
    AddGunToPlayer,
    Fight,
    Exit,
}
