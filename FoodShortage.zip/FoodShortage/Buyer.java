package Java_OOP.Interfaces_and_Abstraction.FoodShortage;

public interface Buyer {
    void buyFood();
    int getFood();
}
