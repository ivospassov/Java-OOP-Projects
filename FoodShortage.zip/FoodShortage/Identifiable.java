package Java_OOP.Interfaces_and_Abstraction.FoodShortage;

public interface Identifiable {
    String getId();
}
