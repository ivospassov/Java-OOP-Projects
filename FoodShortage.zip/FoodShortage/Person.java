package Java_OOP.Interfaces_and_Abstraction.FoodShortage;

public interface Person {
    String getName();
    int getAge();
}
