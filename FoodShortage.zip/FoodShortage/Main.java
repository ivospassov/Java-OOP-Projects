package Java_OOP.Interfaces_and_Abstraction.FoodShortage;

public class Main {
    public static void main(String[] args) {

    }
}
