package CatHouse.entities.toys;

public class Mouse extends BaseToy{
    private final static int DEFAULT_SOFTNESS = 5;
    private final static double DEFAULT_PRICE = 15;

    public Mouse() {
        super(DEFAULT_SOFTNESS, DEFAULT_PRICE);
    }
}
