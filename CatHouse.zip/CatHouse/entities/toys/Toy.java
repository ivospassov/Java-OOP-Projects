package CatHouse.entities.toys;

public interface Toy {
    int getSoftness();

    double getPrice();
}
