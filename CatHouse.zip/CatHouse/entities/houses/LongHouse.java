package CatHouse.entities.houses;

public class LongHouse extends BaseHouse{
    private final static int INITIAL_CAPACITY = 30;

    public LongHouse(String name) {
        super(name, INITIAL_CAPACITY);
    }
}
