package CatHouse.core;

public interface Engine extends Runnable {
}

