package CatHouse.core;

import CatHouse.common.ConstantMessages;
import CatHouse.common.ExceptionMessages;
import CatHouse.entities.cat.Cat;
import CatHouse.entities.cat.LonghairCat;
import CatHouse.entities.cat.ShorthairCat;
import CatHouse.entities.houses.House;
import CatHouse.entities.houses.LongHouse;
import CatHouse.entities.houses.ShortHouse;
import CatHouse.entities.toys.Ball;
import CatHouse.entities.toys.Mouse;
import CatHouse.entities.toys.Toy;
import CatHouse.repositories.ToyRepository;

import java.util.ArrayList;
import java.util.Collection;

public class ControllerImpl implements Controller{
    private ToyRepository toys;
    private Collection<House> houses;

    public ControllerImpl() {
        this.toys = new ToyRepository();
        this.houses = new ArrayList<>();
    }

    @Override
    public String addHouse(String type, String name) {
        House house;
        switch (type) {
            case "ShortHouse":
                house = new ShortHouse(name);
                break;

            case "LongHouse":
                house = new LongHouse(name);
                break;

            default:
                throw new NullPointerException(ExceptionMessages.INVALID_HOUSE_TYPE);
        }
        this.houses.add(house);
        return String.format(ConstantMessages.SUCCESSFULLY_ADDED_HOUSE_TYPE, type);
    }

    @Override
    public String buyToy(String type) {
        Toy toy;
        switch (type) {
            case "Ball":
                toy = new Ball();
                break;

            case "Mouse":
                toy = new Mouse();
                break;

            default:
                throw new NullPointerException(ExceptionMessages.INVALID_TOY_TYPE);
        }
        this.toys.buyToy(toy);
        return String.format(ConstantMessages.SUCCESSFULLY_ADDED_TOY_TYPE, type);
    }

    @Override
    public String toyForHouse(String houseName, String toyType) {
        Toy toy = this.toys.findFirst(toyType);

        if (toy == null) {
            String message = String.format(ExceptionMessages.NO_TOY_FOUND, toyType);
            throw new IllegalStateException(message);
        }

        House house = getHouseByName(houseName);
        house.buyToy(toy);

        this.toys.removeToy(toy);

        return String.format(ConstantMessages.SUCCESSFULLY_ADDED_TOY_IN_HOUSE, toyType, houseName);
    }

    private House getHouseByName(String houseName) {

        return this.houses
                .stream()
                .filter(house -> house.getName().equals(houseName))
                .findFirst()
                .get();
    }

    @Override
    public String addCat(String houseName, String catType, String catName, String catBreed, double price) {
        Cat cat = createCat(catType, catName, catBreed, price);
        House house = this.getHouseByName(houseName);

        return checkValidCatForHouse(catType, houseName, house, cat);
    }

    private String checkValidCatForHouse(String catType, String houseName, House house, Cat cat) {
        boolean isValid = false;

        if (catType.startsWith("Short") && house.getClass().getSimpleName().startsWith("Short")) {
            isValid = true;
        } else if (catType.startsWith("Long") && house.getClass().getSimpleName().startsWith("Long")) {
            isValid = true;
        }
        if (isValid) {
            house.addCat(cat);
            return String.format(ConstantMessages.SUCCESSFULLY_ADDED_CAT_IN_HOUSE, catType, houseName);
        }
        return ConstantMessages.UNSUITABLE_HOUSE;
    }

    private Cat createCat(String catType, String catName, String catBreed, double price) {
        Cat cat;
        switch (catType) {
            case "ShorthairCat":
                cat = new ShorthairCat(catName, catBreed, price);
                break;

            case "LonghairCat":
                cat = new LonghairCat(catName, catBreed, price);
                break;

            default:
                throw new IllegalArgumentException(ExceptionMessages.INVALID_CAT_TYPE);
        }
        return cat;
    }

    @Override
    public String feedingCat(String houseName) {
        House house = this.getHouseByName(houseName);

        house.feeding();

        return String.format(ConstantMessages.FEEDING_CAT, house.getCats().size());
    }

    @Override
    public String sumOfAll(String houseName) {
        House house = this.getHouseByName(houseName);

        double priceCats = house.getCats().stream().mapToDouble(Cat::getPrice).sum();
        double priceToys = house.getToys().stream().mapToDouble(Toy::getPrice).sum();

        double houseValue = priceCats + priceToys;

        return String.format(ConstantMessages.VALUE_HOUSE, houseName, houseValue);
    }

    @Override
    public String getStatistics() {
        StringBuilder stringBuilder = new StringBuilder();
        for (House house : houses) {
            stringBuilder.append(house.getStatistics());
        }
        return stringBuilder.toString();
    }
}
