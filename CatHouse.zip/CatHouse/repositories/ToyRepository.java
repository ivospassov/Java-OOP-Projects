package CatHouse.repositories;

import CatHouse.entities.toys.Toy;

import java.util.*;

public class ToyRepository implements Repository{
    private Set<Toy> toys;

    public ToyRepository() {
        this.toys = new HashSet<>();
    }

    @Override
    public void buyToy(Toy toy) {
        toys.add(toy);
    }

    @Override
    public boolean removeToy(Toy toy) {
        if (this.toys.contains(toy)) {
            this.toys.remove(toy);
            return true;
        }
        return false;
    }

    @Override
    public Toy findFirst(String type) {
        return this.toys.stream().filter(toy -> toy.getClass().getSimpleName().equals(type)).findFirst().get();
    }
}
