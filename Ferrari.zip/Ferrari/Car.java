package Java_OOP.Interfaces_and_Abstraction.Ferrari;

public interface Car {
    String brakes();
    String gas();
}
