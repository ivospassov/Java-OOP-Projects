package Java_OOP.Interfaces_and_Abstraction.Ferrari;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String driverName = scanner.nextLine();
        Ferrari ferrari = new Ferrari("488-Spider");
        print(ferrari, driverName);
    }

    public static void print(Ferrari ferrari, String driverName) {
        System.out.printf("488-Spider/%s/%s/%s%n", ferrari.brakes(), ferrari.gas(), driverName);
    }
}
