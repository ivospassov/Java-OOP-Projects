package Vehicles;

public interface Refuel {
    void refuel(double liters);
}
