package Vehicles;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] carInformation = scanner.nextLine().split("\\s+");
        double fuelQuantity = Double.parseDouble(carInformation[1]);
        double litersPerKm = Double.parseDouble(carInformation[2]);

        String[] truckInformation = scanner.nextLine().split("\\s+");
        double fuelQuantity1 = Double.parseDouble(truckInformation[1]);
        double litersPerKm1 = Double.parseDouble(truckInformation[2]);

        Vehicle car = new Car(fuelQuantity, litersPerKm);
        Vehicle truck = new Truck(fuelQuantity1, litersPerKm1);

        int numberOfCommands = Integer.parseInt(scanner.nextLine());
        for (int i = 1; i <= numberOfCommands; i++) {
            String[] input = scanner.nextLine().split("\\s+");
            String command = input[0];
            String vehicleType = input[1];

            if (command.equals("Drive")) {
                double distance = Double.parseDouble(input[2]);
                if (vehicleType.equals("Car")) {
                    System.out.println(car.drive(distance));
                } else if (vehicleType.equals("Truck")) {
                    System.out.println(truck.drive(distance));
                }
            }


            else if (command.equals("Refuel")) {
                double liters = Double.parseDouble(input[2]);
                if (vehicleType.equals("Car")) {
                    car.refuel(liters);
                } else if (vehicleType.equals("Truck")) {
                    truck.refuel(liters);
                }
            }
        }

        System.out.println(printResult(car, truck));

//        Car 15 0.3
//Truck 100 0.9
//4
//Drive Car 9
//Drive Car 30
//Refuel Car 50
//        Drive Truck 10
    }

    private static String printResult(Vehicle car, Vehicle truck) {
        String result = String.format("Car: %.2f", car.getFuelQuantity()) +
                System.lineSeparator() +
                String.format("Truck: %.2f", truck.getFuelQuantity());
        return result;
    }
}
