package Vehicles;

public interface Drive {
    String drive(double distance);
}
